import pygame

pygame.init()

WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Step 10 - Collision")

clock = pygame.time.Clock() 

class Player(pygame.sprite.Sprite):
  def __init__(self):
    super().__init__()
    self.image = pygame.image.load("dukbird.png")        
    self.image = pygame.transform.scale(self.image, (50, 50))  
    self.rect = self.image.get_rect()
    self.rect.center = (WIDTH // 2, HEIGHT // 2)
    self.speed = 3

  def update(self): 
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
      self.rect.x -= self.speed
    if keys[pygame.K_RIGHT]:
      self.rect.x += self.speed
    if keys[pygame.K_UP]:
      self.rect.y -= self.speed
    if keys[pygame.K_DOWN]:
      self.rect.y += self.speed

    self.rect.clamp_ip(screen.get_rect())

  def update(self):
    self.rect.x += self.speed_x
    if self.rect.left < 50 or self.rect.right > 200:
      self.speed_x *= -1


class Apple(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("apple.png")
        self.image = pygame.transform.scale(self.image,(40,40))

        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.speed_x = 3                  
        self.speed_y = 2                  

    def update(self):
        self.rect.x += self.speed_x       
        self.rect.y += self.speed_y

        # x축
        if self.rect.left < 0 or self.rect.right > WIDTH:
            self.speed_x *= -1
        # y축
        if self.rect.top < 0 or self.rect.bottom > HEIGHT:
            self.speed_y *= -1

all_sprites = pygame.sprite.Group()   
enemy_group = pygame.sprite.Group() 

player = Player()
all_sprites.add(player)

enemy = Apple(50, 260)                
all_sprites.add(enemy)
enemy_group.add(enemy)

apples = [] 


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((5, 20))
        self.image.fill(white)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speed_y = -2

    def shoot(self):
        vertical_offset = 25 
        
        bullet_bottom = Bullet(self.rect.centerx, self.rect.top)
      
        all_sprites.add(bullet_bottom)

    def update(self):
        self.rect.y += self.speed_y
        if self.rect.bottom < 0:
            self.kill()


all_sprites = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

running = True
game_over = False   

while running:
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = False

  #변경: 게임 오버가 아닐 때만 움직임/충돌 처리
  if not game_over:
    all_sprites.update() #추가: game_over == False 일 때만 업데이트


    # 2) Sprite 그룹끼리 충돌: 플레이어 vs enemy_group
    hits = pygame.sprite.spritecollide(player, enemy_group, False)
    if hits:
      print("적과 충돌! 게임 오버")
      game_over = True             #추가: 창은 유지, 상태만 게임오버로

  # ---------------- 그림 그리기 영역 ----------------
  screen.fill((170, 200, 255))  
  pygame.draw.rect(screen, (80, 170, 80), (0, HEIGHT - 60, WIDTH, 60))  # 땅


  pygame.draw.line(screen, (0, 0, 0), (300, 300), (500, 300), 5)  # 장애물 선
 
  all_sprites.draw(screen)  #추가: Sprite 그룹 그리기 (Player + Enemy)

  #추가: 점수 텍스트 출력해서 진짜 게임 느낌
  font = pygame.font.SysFont(None, 24)
  text = font.render(f"Score: {score}", True, (0, 0, 0))
  screen.blit(text, (10, 10))

  #추가: 게임오버 메시지 (플래그가 True일 때만)
  if game_over:
    over_text = font.render("GAME OVER (Press R to Reset)", True, (255, 0, 0))
    over_x = (WIDTH - over_text.get_width()) // 2 
    over_y = (HEIGHT - over_text.get_height()) // 2 
    screen.blit(over_text, (over_x, over_y))

  pygame.display.flip()
  clock.tick(60)
pygame.quit()