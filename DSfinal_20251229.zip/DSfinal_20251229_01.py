import tkinter as tk
import math

class DrawableShape:
    def __init__(self, x, y): self.x, self.y = x, y
    def area(self): raise NotImplementedError
    def perimeter(self): raise NotImplementedError
    def draw(self, canvas): raise NotImplementedError

class Square(DrawableShape):
    def __init__(self, x, y, w, h):
        super().__init__(x, y)
        self.w, self.h = w, h
    def area(self): return self.w * self.h
    def perimeter(self): return 2 * (self.w + self.h)
    def draw(self, canvas):
        canvas.create_square(self.x, self.y, self.x + self.w, self.y + self.h)

class Circle(DrawableShape):
    def __init__(self, x, y, r):
        super().__init__(x, y)
        self.r = r
    def area(self): return math.pi * self.r ** 2
    def perimeter(self): return 2 * math.pi * self.r
    def draw(self, canvas):
        canvas.create_oval(self.x - self.r, self.y - self.r, self.x + self.r, self.y + self.r, fill="skyblue")

root = tk.Tk()
root.title("문제1")
canvas = tk.Canvas(root, width=400, height=300, bg="white")
canvas.pack(pady=10)

var = tk.StringVar(value="rect")
info = tk.StringVar(value="도형을 선택하고 그리기를 누르세요.")
tk.Label(root, textvariable=info).pack()


left = tk.Frame(root, padx=8, pady=8)
left.pack(side="left", fill="both", expand=True)
right = tk.Frame(root, padx=8, pady=8)
right.pack(side="right", fill="both", expand=True)




def draw_shape():
    canvas.delete("all")
    if var.get() == "rect":
        s = Square(50, 50, 100, 60)
    else:
        s = Circle(150, 110, 40)
    s.draw(canvas)
    info.set(f"면적={s.area():.2f}, 둘레={s.perimeter():.2f}")

tk.Button(root, text="사각형 추가", command=draw_shape).pack(side="left", padx=10)
tk.Button(root, text="원 추가", command=draw_shape).pack(side="left", padx=10)
tk.Button(root, text="모두 그리기", command=draw_shape).pack(side="left", padx=10)

root.mainloop()