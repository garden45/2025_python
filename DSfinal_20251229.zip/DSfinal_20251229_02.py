import tkinter as tk

class Person:
    def __init__(self, name):
        self.name = name

class HobbyPerson(Person):
    def __init__(self, name):
        super().__init__(name)
        self.hobbies = []

    def add_hobby(self, hobby):
        self.clear_hobbies()
        if hobby not in self.hobbies and hobby != "None":
            self.hobbies.append(hobby)

    def clear_hobbies(self):
        self.hobbies.clear()

root = tk.Tk()
root.title("문제 2")
root.geometry("380x260")

stu = HobbyPerson("김덕성")
title = tk.Label(root, text=f"학생: {stu.name}", font=("맑은고딕", 11, "bold"))
title.pack(pady=10)

frm = tk.Frame(root)
frm.pack(pady=10, anchor="center")


var_course = tk.StringVar(value="None")


rb1 = tk.Radiobutton(frm, text="게임", variable=var_course, value="게임")
rb2 = tk.Radiobutton(frm, text="독서", variable=var_course, value="독서")
rb3 = tk.Radiobutton(frm, text="운동", variable=var_course, value="운동")


rb1.grid(row=0, column=0, padx=8, pady=4, sticky="w")
rb2.grid(row=0, column=1, padx=8, pady=4, sticky="w")
rb3.grid(row=0, column=2, padx=8, pady=4, sticky="w")


result = tk.StringVar(value="취미를 선택하고 [등록하기]를 누르세요.")
lb = tk.Label(root, textvariable=result, wraplength=340, justify="left")
lb.pack(pady=10)

def register_courses():
    selected_course = var_course.get()

    stu.add_hobby(selected_course)

    if stu.hobbies:
        result.set(f"등록된 취미: {stu.hobbies[0]}")
    else:
        result.set("선택된 취미가 없습니다.")

def reset_all():
    var_course.set("None")
    stu.clear_hobbies()
    result.set("모든 선택을 해제했습니다.")

button_frame = tk.Frame(root)
button_frame.pack(pady=10)

tk.Button(button_frame, text="등록하기", command=register_courses).pack(side="left", padx=10)
tk.Button(button_frame, text="초기화", command=reset_all).pack(side="left", padx=10)

root.mainloop()